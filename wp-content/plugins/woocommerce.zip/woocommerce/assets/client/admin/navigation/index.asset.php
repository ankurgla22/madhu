<?php return array('dependencies' => array('lodash', 'wc-settings', 'wp-element', 'wp-hooks', 'wp-i18n', 'wp-url'), 'version' => 'cc18d1034647e047b447');
