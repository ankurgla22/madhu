<?php return array('dependencies' => array(), 'version' => 'd3897f08e2d5f8459306');
