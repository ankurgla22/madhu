<?php return array('dependencies' => array('lodash', 'moment', 'wp-i18n'), 'version' => '43b5c0ca1706f1dcaa7e');
